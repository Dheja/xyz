package com.cg.airlines_reservation_system.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class BookingInformation {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int bookingId;
	private String custEmail;
	private int noOfPassengers;
	private String classType;
	private float totalFare;
	private int seatNumber;
	private String creditCardInfo;
	private String destCity;
}

