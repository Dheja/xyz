package com.cg.airlines_reservation_system.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.Data;



@Data
@Entity
public class FlightInformation {
	
	@Id 
	@GeneratedValue(strategy=GenerationType.SEQUENCE) 
	private int flightNo;
	private String airline;
	private String dep_city;
	private String arr_city;
	private String arr_date;
	private String dep_date;
	private String dep_time;
	private String arr_time;
	private int firstSeats;
	private float firstSeatsFare;
	private int businessSeats;
	private float businessSeatsFare;
	
		
}

