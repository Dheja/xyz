package com.cg.airlines_reservation_system.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import lombok.Data;



@Data
@Entity
public class FlightInformation {
	
	@Id 
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="flight_seq")
	@SequenceGenerator(name="flight_seq",sequenceName="flight_seq",allocationSize=1,initialValue=100)
	private int flightNo;
	private String airline;
	private String depCity;
	private String arrCity;
	private String arrDate;
	private String depDate;
	private String depTime;
	private String arrTime;
	private int firstSeats;
	private float firstSeatsFare;
	private int businessSeats;
	private float businessSeatsFare;
	
		
}

