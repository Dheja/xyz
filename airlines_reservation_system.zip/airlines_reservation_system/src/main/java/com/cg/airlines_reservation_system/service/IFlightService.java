package com.cg.airlines_reservation_system.service;

import java.util.List;

import com.cg.airlines_reservation_system.entity.FlightInformation;

public interface IFlightService {

	public	List<FlightInformation> getAllFlights();

	public FlightInformation addFlight(FlightInformation flight);

	public String deleteFlight(int flightNo);

	public FlightInformation updateFlight(FlightInformation flight);

	public List<FlightInformation> getParticularFlights(String depDate,String arrCity);

	

	

}
