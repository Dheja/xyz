package com.cg.airlines_reservation_system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.airlines_reservation_system.entity.FlightInformation;
import com.cg.airlines_reservation_system.repository.FlightRepository;

@Service
public class FlightService implements IFlightService {

	@Autowired
	private FlightRepository fr;

	@Override
	public List<FlightInformation> getAllFlights() {

		return fr.findAll();
	}

	@Override
	public FlightInformation addFlight(FlightInformation flight) {
		return fr.saveAndFlush(flight);
		}

	@Override
	public String deleteFlight(int flightNo) {
		fr.deleteById(flightNo);
		return "Flight Details Deleted Successfully";
		
	}

	@Override
	public FlightInformation updateFlight(FlightInformation flight) {
		return fr.saveAndFlush( flight);
	
	}

	@Override
	public List<FlightInformation> getParticularFlights(String depDate, String arrCity) {
		return fr.getParticularFlights(depDate,arrCity);	
	}



}
