package com.cg.airlines_reservation_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.airlines_reservation_system.entity.FlightInformation;

public interface FlightRepository extends JpaRepository<FlightInformation, Integer>{

	

	

}
