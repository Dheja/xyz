package com.cg.airlines_reservation_system.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.airlines_reservation_system.entity.FlightInformation;
import com.cg.airlines_reservation_system.service.IFlightService;


@RestController
public class Controller {
	@Autowired
	private IFlightService fs;
	
	@RequestMapping("/hello")
	public String sayHello() {
		return "Hello world";
	}
	@RequestMapping("/getAllFlights")
	public List<FlightInformation> getAllFlights() {
		return fs.getAllFlights();
	}
	
	@RequestMapping(value="/addFlight", method=RequestMethod.POST)
	public FlightInformation addFlight(@RequestBody FlightInformation flight) {
		
		/* FlightInformation flightInformation1 = new FlightInformation(); */
		
		return  fs.addFlight(flight);
	}
	@RequestMapping(value="/deleteFlight/{flightNo}",method=RequestMethod.DELETE)
	public String deleteFlight(@PathVariable int flightNo) {
		
		/* FlightInformation flightInformation1 = new FlightInformation(); */
		
		return  fs.deleteFlight(flightNo);
	}
	
	@RequestMapping(value="/updateFlight", method=RequestMethod.PUT)
	public FlightInformation updateFlight(@RequestBody FlightInformation flight) {
		
		/* FlightInformation flightInformation1 = new FlightInformation(); */
		
		return  fs.updateFlight(flight);
	}
	

	
}
