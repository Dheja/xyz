package com.cg.airlines_reservation_system.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Airport {

	
	@Id
	private String airportName;
	private String abbreviation;
	private String location;
}
