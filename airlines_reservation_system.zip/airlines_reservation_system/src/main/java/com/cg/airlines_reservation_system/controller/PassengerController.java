package com.cg.airlines_reservation_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.airlines_reservation_system.entity.FlightInformation;
import com.cg.airlines_reservation_system.service.IFlightService;

@RestController
public class PassengerController {
	
	@Autowired
	private IFlightService fs;
	
	@RequestMapping("flights/{depDate}/{arrCity}")
		public List<FlightInformation> getParticularFlights(@PathVariable String depDate,@PathVariable String arrCity){
		depDate = depDate.replace('-','/');	
		return fs.getParticularFlights(depDate,arrCity);}
}
