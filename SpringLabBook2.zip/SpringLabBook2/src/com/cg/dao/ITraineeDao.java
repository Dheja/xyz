package com.cg.dao;

import java.util.List;

import com.cg.entity.Trainee;
import com.cg.entity.User;

public interface ITraineeDao {

	boolean checkUser(User user);

	void save(Trainee trainee);

	void delete(int traineeId);

	Trainee fetch(int traineeId);

	List<Trainee> getAllTrainees();

	void update(Trainee trainee);

}
