package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entity.Trainee;
import com.cg.entity.User;

@Repository
public class TraineeDaoImpl implements ITraineeDao {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public boolean checkUser(User user) {
		//User us = null;
		//us = entityManager.find(User.class, user.getUsername());
		if (/* us != null && */ ("admin").equals(user.getUsername()) && ("admin").equals(user.getPassword())) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void save(Trainee trainee) {

		entityManager.persist(trainee);
		entityManager.flush();

	}

	@Override
	public void delete(int traineeId) {
		Trainee trainee = null;
		trainee = entityManager.find(Trainee.class, traineeId);
		entityManager.remove(trainee);
	}

	@Override
	public Trainee fetch(int traineeId) {
		Trainee trainee = null;
		trainee = entityManager.find(Trainee.class, traineeId);
		return trainee;
	}

	@Override
	public List<Trainee> getAllTrainees() {
		TypedQuery<Trainee> query = entityManager.createQuery("SELECT t FROM Trainee t", Trainee.class);
		return query.getResultList();
	}

	@Override
	public void update(Trainee trainee) {
		entityManager.merge(trainee);
		entityManager.flush();
	}

}
