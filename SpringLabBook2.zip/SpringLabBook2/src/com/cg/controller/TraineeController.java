package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.entity.Trainee;
import com.cg.entity.User;
import com.cg.service.ITraineeService;

@Controller	
public class TraineeController {
	@Autowired
	private ITraineeService service;
	
	@RequestMapping(name="/checkuser",method=RequestMethod.POST)
	public String login(String username,String password) {
		User user=new User();
		user.setUsername(username);
		user.setPassword(password);
		boolean result=service.checkUser(user);
		if(result) {
			return "services";
		}else {
			return "error";
		}
	}
	
	@RequestMapping(name="/details")
	public String details(Model model) {
		model.addAttribute("domains",new String[]{"JEE",".NET","Web Services","Oracle"});
		model.addAttribute("trainee",new Trainee());
		return "addtrainee";
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String saveTrainee(@ModelAttribute("trainee") Trainee trainee, Model model){
		 service.save(trainee);
		model.addAttribute("message","Employee with id "+trainee.getTraineeId()+" added successfully!");
		model.addAttribute("trainee", trainee);
		return "success";
	}
	@RequestMapping(value="/delTrainee",method=RequestMethod.POST)
	public String deleteTrainee(int traineeId,Model model){
		service.delete(traineeId);
		return "deletedView";
	}
	@RequestMapping(value="/fetch",method=RequestMethod.POST)
	public String fetchTrainee(int traineeId,Model model){
		Trainee trainee=null;
		trainee=service.fetch(traineeId);
		model.addAttribute("trainee", trainee);
		return "deleteview";
	}
	
	@RequestMapping(value="/retrieve",method=RequestMethod.POST)
	public String retrieveTrainee(int traineeId,Model model){
		Trainee trainee=null;
		trainee=service.fetch(traineeId);
		model.addAttribute("trainee", trainee);
		return "retrieveview";
	}
	
	@RequestMapping(value="/retriveall")
	public String retriveAllTrainees(Model model) {
		List<Trainee> list=service.getAllTrainees();
		model.addAttribute("list", list);
		return "retriveAllView";
	}
	
	@RequestMapping(value="/getTrainee",method=RequestMethod.POST)
	public String getTrainee(int traineeId,Model model){
		Trainee trainee=null;
		trainee=service.fetch(traineeId);
		model.addAttribute("domains",new String[]{"JEE",".NET","Web Services","Oracle"});
		model.addAttribute("trainee", trainee);
		return "modifyview";
	}
	@RequestMapping(value="/modify",method=RequestMethod.POST)
	public String modifyTrainee(@ModelAttribute("trainee") Trainee trainee, Model model){
		 service.update(trainee);
		model.addAttribute("message","Employee with id "+trainee.getTraineeId()+" added successfully!");
		model.addAttribute("trainee", trainee);
		return "success";
	}
	
	
	
}
