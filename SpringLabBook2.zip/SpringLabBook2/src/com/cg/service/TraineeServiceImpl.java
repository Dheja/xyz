package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ITraineeDao;
import com.cg.entity.Trainee;
import com.cg.entity.User;

@Service
@Transactional
public class TraineeServiceImpl implements ITraineeService {
	
	@Autowired
	private ITraineeDao dao;

	@Override
	public boolean checkUser(User user) {
		
		return dao.checkUser(user);
	}

	@Override
	public void save(Trainee trainee) {
		 dao.save(trainee);
	}

	@Override
	public void delete(int traineeId) {
		 dao.delete(traineeId);
	}

	@Override
	public Trainee fetch(int traineeId) {
		
		return dao.fetch(traineeId);
	}

	@Override
	public List<Trainee> getAllTrainees() {
		
		return dao.getAllTrainees() ;
	}

	@Override
	public void update(Trainee trainee) {
		dao.update(trainee);
		
	}

}
